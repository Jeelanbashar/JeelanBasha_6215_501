public class Main {

	public static void main(String[] args) {
		

		        Student[] test = new Student[5];

	                          for(int i=0; i<5;i++)

        {
	            Scanner kb = new Scanner(System.in);

	            System.out.println("What is the Students name?: ");

	            test[i].setName(kb.nextLine());

	            System.out.println("What is the Students ID number?: ");

	            test[i].setIdnum(kb.nextLine());

	            System.out.println("What is the Students major?: ");

	            test[i].setMajor(kb.nextLine());

	            System.out.println("What is the Students anticipated year of " );
                            
                             test[i].setyear(kb.nextLine());
                             
                             System.out.println("what is mark");
                            
                             test[i].setmark(kb.nextLine());


	      

	        }
	}

}
